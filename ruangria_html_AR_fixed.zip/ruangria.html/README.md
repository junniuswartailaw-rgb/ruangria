# RuangRia: AR Bangun Ruang (versi perbaikan AR lintas perangkat)

Aplikasi HTML5 statis. `script.js` dan `style.css` adalah hasil build (React, Three.js, font, ilustrasi sudah di dalamnya). Folder `src/` proyek asli tidak ada di ZIP, jadi perbaikan AR dibuat sebagai modul terpisah yang mudah dibaca: `ar-camera.js` dan `ar-camera.css`.

## Cara kerja AR sekarang (dua jalur otomatis)

| Jalur | Dipakai saat | Kemampuan |
|---|---|---|
| WebXR `immersive-ar` (kode asli, tidak diubah) | Android Chrome dengan ARCore | Deteksi permukaan lantai atau meja, ketuk untuk meletakkan bangun |
| Mode kamera (baru, `ar-camera.js`) | Semua perangkat lain: iPhone, iPad, Android tanpa ARCore, tablet, laptop dan PC dengan webcam | Kamera sebagai latar, bangun 3D di atasnya, sensor gerak membuat bangun "terkunci" di ruang, geser untuk memutar, cubit atau gulir untuk ukuran, dua jari untuk memindahkan |

Mode kamera TIDAK mendeteksi permukaan. Bangun muncul di arah pandang kamera saat AR dibuka atau saat tombol **Atur ulang** ditekan. Tanpa sensor gerak (misalnya laptop), bangun menempel di layar dan dikendalikan dengan geser dan gulir.
Jika kamera tidak ada atau ditolak, muncul pesan jelas dan pengguna kembali ke viewer 3D biasa.

Untuk menguji mode kamera di HP yang punya WebXR, buka alamat dengan tambahan `?ar=camera`, misalnya `https://situsmu.example/?ar=camera`.

## Penyebab masalah yang ditemukan

1. **AR hanya memakai WebXR `immersive-ar`, tanpa cadangan.** Fungsi `B3` di `script.js` langsung menolak jika `navigator.xr` tidak ada atau tidak mendukung `immersive-ar`. Safari di iPhone dan iPad tidak menyediakan WebXR AR, begitu juga banyak Android tanpa ARCore dan semua desktop. Hasilnya tombol "Lihat dalam AR" hanya memunculkan modal "AR belum didukung" dan kamera tidak pernah dibuka. Ini sudah direproduksi pada versi asli.
2. **Tidak ada `getUserMedia`**, sehingga tidak ada jalur kamera biasa.
3. **File ikon PNG tidak ada** (`icon-192.png`, `icon-512.png`) padahal dirujuk `index.html` dan `manifest.json`, sehingga ikon PWA dan ikon layar utama iPhone gagal dimuat (404).
4. **Meta viewport belum mendukung layar berponi** (`viewport-fit=cover`).
5. **Teks modal galat** hanya menyebut WebXR dan tidak memberi petunjuk izin kamera atau alternatif.

## Daftar perubahan

| File | Perubahan |
|---|---|
| `ar-camera.js` (baru) | Mode kamera: `getUserMedia`, Three.js bawaan aplikasi, sensor gerak, gestur, ganti kamera depan atau belakang, penanganan galat dan pembersihan sumber daya |
| `ar-camera.css` (baru) | Gaya overlay AR, mengikuti warna dan huruf overlay asli, aman untuk poni dan landscape, tombol minimal 44 px |
| `script.js` | `B3` asli diganti nama `B3xr` dan tidak diubah. `B3` baru memilih WebXR bila tersedia, jika tidak atau gagal beralih ke mode kamera. Teks modal diperbarui. Selebihnya (materi, jaring-jaring, kuis, musik, nilai) tidak disentuh |
| `index.html` | Memuat modul baru, `viewport-fit=cover`, ikon iOS `icon-180.png`, meta PWA tambahan |
| `manifest.json` | Ikon PNG lengkap termasuk ikon maskable terpisah, `id`, `lang` |
| `service-worker.js` | Cache naik ke `v4`, aset baru ikut di-cache (AR kamera tetap bisa dibuka offline setelah kunjungan pertama) |
| `icons/` | Ditambah `icon-180.png`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` dari desain asli |
| `_headers`, `.nojekyll` (baru) | Konfigurasi Netlify, Cloudflare Pages, dan GitHub Pages |

## Menjalankan di komputer sendiri

```sh
cd folder-ruangria
python3 -m http.server 8000
```

Buka `http://localhost:8000` di komputer. Jangan buka `index.html` langsung (`file://`), kamera dan service worker akan diblokir.

**Penting untuk uji di HP:** alamat jaringan lokal seperti `http://192.168.1.5:8000` BUKAN konteks aman, jadi browser HP memblokir kamera. Pilih salah satu:
- Unggah ke hosting HTTPS (cara termudah, lihat bawah).
- Terowongan HTTPS sementara, misalnya `npx localtunnel --port 8000` atau `cloudflared tunnel --url http://localhost:8000`, lalu buka tautan `https://` yang diberikan di HP.
- Android Chrome lewat kabel USB: buka `chrome://inspect/#devices` di komputer, aktifkan port forwarding 8000, lalu buka `http://localhost:8000` di HP.

## Mengunggah ke hosting HTTPS

Semua layanan ini gratis dan otomatis HTTPS. Unggah isi folder ini (bukan ZIP-nya).
- **Netlify:** masuk ke app.netlify.com/drop lalu seret folder.
- **Cloudflare Pages:** Upload assets, pilih folder.
- **GitHub Pages:** unggah ke repositori, Settings, Pages, pilih branch `main` dan folder root. `.nojekyll` sudah disediakan.

Setelah mengubah file, naikkan angka `CACHE_NAME` di `service-worker.js` (misalnya `v5`) agar pengguna lama menerima versi baru.

## Panduan pengujian

Lakukan di tautan HTTPS, bukan `file://`.

**Android (Chrome)**
1. Buka tautan, masuk Materi, pilih bangun, ketuk **Lihat dalam AR**.
2. Jika HP mendukung ARCore: layar AR asli muncul, arahkan ke lantai atau meja, ketuk saat lingkaran putih muncul.
3. Jika tidak: Chrome meminta izin kamera, ketuk Izinkan, bangun muncul di atas kamera. Gerakkan HP, bangun tetap di tempatnya.
4. Uji geser, cubit, **Atur ulang**, **Ganti kamera**, **Tutup AR**.
5. Uji tolak izin: pesan galat harus muncul dan tombol "Kembali ke model 3D" berfungsi.

**iPhone dan iPad (Safari)**
1. Ketuk **Lihat dalam AR**. Safari menampilkan dua dialog: izin gerakan dan orientasi (ketuk Izinkan), lalu izin kamera (ketuk Izinkan).
2. Jika salah menolak: ikon "aA" di bilah alamat, Pengaturan Situs, izinkan Kamera dan Gerakan, lalu muat ulang.
3. Browser lain di iOS (Chrome, Firefox) memakai mesin Safari dan umumnya berfungsi sama. Buka dari aplikasi seperti WhatsApp atau Instagram sering gagal, gunakan "Buka di Safari".
4. Opsional: Bagikan, Tambah ke Layar Utama untuk memasang sebagai PWA.

**Tablet:** sama seperti HP. Putar layar saat AR terbuka, tampilan harus menyesuaikan.

**Komputer:** buka di Chrome, Edge, Firefox, atau Safari, izinkan webcam. Geser mouse untuk memutar, roda mouse untuk ukuran. `Esc` menutup AR.

## Pengujian yang sudah dilakukan

Dijalankan di Chromium otomatis (Playwright) dengan kamera palsu dan WebGL software: emulasi Pixel 7 (portrait dan landscape), iPhone 14, iPad, dan desktop 1366x768. Yang lolos: pembukaan kamera, tampilan video dan model 3D, ketujuh bangun, geser, cubit dua jari, roda mouse, Atur ulang, Tutup AR dan pembersihan (kamera mati, overlay hilang, scroll kembali), buka tutup berulang, rotasi layar saat AR terbuka, sensor gerak (event disimulasikan), alur izin sensor iOS (disimulasikan), penolakan izin, kamera tidak ada, kamera dipakai aplikasi lain, API kamera tidak ada, HTTP tidak aman, WebXR yang gagal lalu beralih ke mode kamera, pemuatan ikon dan manifest, serta service worker dan reload offline. Tidak ada galat console.

## Keterbatasan yang masih ada

- **Belum diuji di perangkat fisik.** Tidak ada iPhone, Safari asli, atau HP Android asli di lingkungan pengujian, jadi perilaku nyata sensor gerak, kalibrasi arah, performa di HP menengah, dan dialog izin Safari belum diverifikasi. Emulasi iPhone di atas hanyalah Chromium dengan profil perangkat. Uji di perangkat sungguhan sebelum dipakai untuk sidang atau penelitian dan catat hasilnya.
- **Jalur WebXR (Android ARCore) tidak bisa diuji** di lingkungan ini. Kodenya tidak diubah dari versi asli.
- **Mode kamera bukan pelacakan permukaan.** Tidak ada pengenalan lantai atau meja dan tidak ada skala dunia nyata. Bangun bisa bergeser pelan (drift) mengikuti akurasi giroskop. Di perangkat tanpa giroskop (laptop), bangun menempel di layar.
- **Safari iOS tidak mendukung WebXR AR.** Pelacakan permukaan di iPhone hanya mungkin lewat AR Quick Look (file USDZ). Itu belum dibuat di versi ini dan butuh pengujian di iPhone asli.
- **Tidak ada pelacakan marker atau gambar** (AR.js atau MindAR) karena aplikasi asli tidak memakainya dan tidak ada marker yang diminta.
- Browser dalam aplikasi (WhatsApp, Instagram, TikTok) sering memblokir kamera. Pengguna perlu membuka di browser biasa.
- Perangkat tanpa kamera atau tanpa WebGL tetap bisa memakai viewer 3D biasa. Klaim "berjalan di perangkat apa pun" tidak bisa dijamin, yang dijamin hanya adanya pesan jelas dan alternatif.
- PWA hanya membuat aplikasi bisa dipasang dan berjalan offline. PWA tidak menambah kemampuan AR.
